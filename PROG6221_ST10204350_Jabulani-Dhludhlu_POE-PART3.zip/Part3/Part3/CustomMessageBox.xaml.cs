﻿using System.Windows;

namespace Part3
{
    public partial class CustomMessageBox : Window
    {
        public CustomMessageBox(string message, bool isWarning = false)
        {
            InitializeComponent();
            MessageTextBlock.Text = message;
            if (isWarning)
            {
                MessageTextBlock.Foreground = System.Windows.Media.Brushes.Red;
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
